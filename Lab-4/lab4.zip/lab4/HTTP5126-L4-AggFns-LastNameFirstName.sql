-- LAB 4 AGGREGATE FUNCTIONS
-- Put your answers on the lines after each letter. E.g. your query for question 1A should go on line 6; your query for question 1B should go on line 8...

--  1 
-- A

-- B

-- C

-- D


--  2
-- A

-- B

-- C


--  3
-- A

-- B


--  4
-- A